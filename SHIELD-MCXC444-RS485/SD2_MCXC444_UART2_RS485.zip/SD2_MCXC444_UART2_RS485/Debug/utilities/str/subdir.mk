################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../utilities/str/fsl_str.c 

C_DEPS += \
./utilities/str/fsl_str.d 

OBJS += \
./utilities/str/fsl_str.o 


# Each subdirectory must supply rules for building sources it contributes
utilities/str/%.o: ../utilities/str/%.c utilities/str/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DCPU_MCXC444VLH -DCPU_MCXC444VLH_cm0plus -DSDK_OS_BAREMETAL -DSDK_DEBUGCONSOLE=1 -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -DSERIAL_PORT_TYPE_UART=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\board" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\utilities\debug_console_lite" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\source" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS\m-profile" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\utilities" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\utilities\str" -I"D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\component\uart" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m0plus -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-utilities-2f-str

clean-utilities-2f-str:
	-$(RM) ./utilities/str/fsl_str.d ./utilities/str/fsl_str.o

.PHONY: clean-utilities-2f-str

