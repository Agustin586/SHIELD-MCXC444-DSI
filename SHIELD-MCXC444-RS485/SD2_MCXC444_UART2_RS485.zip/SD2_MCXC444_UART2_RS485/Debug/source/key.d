source/key.o source/key.d: ../source/key.c ../source/key.h \
 ../source/SD2_board.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_GPIO.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_COMMON.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/core_cm0plus.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_version.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_compiler.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_gcc.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/system_MCXC444.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_features.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PORT.h
../source/key.h:
../source/SD2_board.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_GPIO.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_COMMON.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/core_cm0plus.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_version.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_compiler.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_gcc.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/system_MCXC444.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_features.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PORT.h:
