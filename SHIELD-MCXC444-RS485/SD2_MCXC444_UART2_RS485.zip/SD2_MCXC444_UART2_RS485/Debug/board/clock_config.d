board/clock_config.o board/clock_config.d: ../board/clock_config.c \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_smc.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_common.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/fsl_device_registers.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_ADC.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_COMMON.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/core_cm0plus.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_version.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_compiler.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_gcc.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/system_MCXC444.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_features.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_CMP.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_DAC.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_DMA.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_DMAMUX.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_FGPIO.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_FLEXIO.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_FTFA.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_GPIO.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_I2C.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_I2S.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LCD.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LLWU.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LPTMR.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LPUART.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MCG.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MCM.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MTB.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MTBDWT.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_NV.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_OSC.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PIT.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PMC.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PORT.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_RCM.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_RFSYS.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_ROM.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_RTC.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_SIM.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_SMC.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_SPI.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_TPM.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_UART.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_USB.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_VREF.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_common_arm.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_clock.h \
 ../board/clock_config.h \
 D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_common.h
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_smc.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_common.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/fsl_device_registers.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_ADC.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_COMMON.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/core_cm0plus.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_version.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_compiler.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\CMSIS/cmsis_gcc.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/system_MCXC444.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device/MCXC444_features.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_CMP.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_DAC.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_DMA.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_DMAMUX.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_FGPIO.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_FLEXIO.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_FTFA.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_GPIO.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_I2C.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_I2S.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LCD.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LLWU.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LPTMR.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_LPUART.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MCG.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MCM.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MTB.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_MTBDWT.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_NV.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_OSC.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PIT.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PMC.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_PORT.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_RCM.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_RFSYS.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_ROM.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_RTC.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_SIM.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_SMC.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_SPI.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_TPM.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_UART.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_USB.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\device\periph2/PERI_VREF.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_common_arm.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_clock.h:
../board/clock_config.h:
D:\aguat\Downloads\SD2_MCXC444_UART2_RS485-main\SD2_MCXC444_UART2_RS485-main\drivers/fsl_common.h:
